//
//  LThreePopview.m
//  eDAIFUProject
//
//  Created by 刘文超 on 2017/11/4.
//  Copyright © 2017年 刘文超. All rights reserved.
//

#import "LThreePopview.h"
#import "LsecondTableViewCell.h"
#import "LdataModel.h"
#import "LsonModel.h"
#import "Masonry.h"
#define LMORENCOLOR RGB(100, 147, 211, 1)
#ifndef RGB
#define RGB(R,G,B,A) [UIColor colorWithRed:R/255.0f green:G/255.0f blue:B/255.0f alpha:A]
#endif
@interface LThreePopview ()<UITableViewDelegate,UITableViewDataSource,LsecondTableViewCellDelegate>
@property(nonatomic,strong)UIView *lwc_headView;
@property(nonatomic,strong)NSMutableArray *lwc_selectArr;
@property(nonatomic,strong)NSMutableArray *lwc_selectnameArr;
@end
@implementation LThreePopview
-(NSMutableArray *)lwc_selectArr
{
    if (!_lwc_selectArr) {
        _lwc_selectArr=[[NSMutableArray alloc]init];
    }return _lwc_selectArr;
}
-(NSMutableArray *)lwc_selectnameArr
{
    if (!_lwc_selectnameArr) {
        _lwc_selectnameArr=[[NSMutableArray alloc]init];
    }return _lwc_selectnameArr;
}
-(instancetype)initWithFrame:(CGRect)frame
{
    if (self=[super initWithFrame:frame]) {
        self.layer.cornerRadius=5;
        self.layer.masksToBounds=YES;
        [self setUI];
    }return self;
}
-(instancetype)init{
    if (self=[super init]) {
        [self setUI];
    }return self;
}

-(void)setDataArr:(NSArray *)dataArr
{
    _dataArr=dataArr;
    
    [self.lwc_tableview reloadData];
    
}

-(void)setUI{
    
    UITableView *myTableView=[[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height) style:UITableViewStyleGrouped];
    [self addSubview:myTableView];
    myTableView.delegate=self;
    myTableView.dataSource=self;
    myTableView.bounces=NO;
    myTableView.tableHeaderView=self.lwc_headView;
    self.lwc_tableview=myTableView;
    myTableView.backgroundColor=[UIColor groupTableViewBackgroundColor];
    
}

#pragma mark-------返回按钮方法
-(void)DissMissClick:(UIButton *)sender{
    
    [self removeFromSuperview];
    
}
-(UIView *)lwc_headView
{
    if (!_lwc_headView) {
        _lwc_headView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width, 30)];
        _lwc_headView.backgroundColor=[UIColor colorWithRed:233.0f/255.0f green:233.0f/255.0f blue:233.0f/255.0f alpha:1];
//        _lwc_headView.backgroundColor=[UIColor whiteColor];
        
        UIButton *button=[[UIButton alloc]init];
        [_lwc_headView addSubview:button];
        [button setImage:[UIImage imageNamed:@"success"] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(DissMissClick:) forControlEvents:UIControlEventTouchUpInside];
        
        [button mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.offset(10);
            make.centerY.offset(0);
            make.height.width.offset(25);
        }];
        
        
        UIButton *chabutton=[[UIButton alloc]init];
        [_lwc_headView addSubview:chabutton];
        [chabutton setImage:[UIImage imageNamed:@"cha"] forState:UIControlStateNormal];
        [chabutton addTarget:self action:@selector(DissMissClick:) forControlEvents:UIControlEventTouchUpInside];
        
        [chabutton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.offset(-10);
            make.centerY.offset(0);
            make.height.width.offset(25);
        }];
     
    }return _lwc_headView;
    
    
}



-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.dataArr.count;
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    
    
    UIView *cell=[[UIView alloc]init];
    cell.backgroundColor=[UIColor whiteColor];
    LdataModel *model=self.dataArr[section];
    
    UILabel *leftLabel=[[UILabel alloc]init];
    [cell addSubview:leftLabel];
    leftLabel.font=[UIFont systemFontOfSize:14 weight:3];
    leftLabel.text=model.name;
    leftLabel.textColor=LMORENCOLOR;
    [leftLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.offset(10);
        make.centerY.offset(0);
        make.height.offset(20);
        
    }];
    
    
    UIButton *button=[[UIButton alloc]init];
    [cell addSubview:button];
    [button setImage:[UIImage imageNamed:@"boxyCheckSelect"] forState:UIControlStateSelected];
    [button setImage:[UIImage imageNamed:@"boxyCheckNot"] forState:UIControlStateNormal];
    [button addTarget:self action:@selector(BtnClick:) forControlEvents:UIControlEventTouchUpInside];
    button.tag=10000+section;
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.offset(-10);
        make.centerY.offset(0);
        make.height.width.offset(30);
    }];
    cell.backgroundColor=[UIColor clearColor];
    return cell;
    
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return .1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 40;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSString *cellID= [NSString stringWithFormat:@"cell%ld %ld",indexPath.section,(long)indexPath.row];
    LsecondTableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell==nil) {
        cell=[[LsecondTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }
    LdataModel *model=self.dataArr[indexPath.section];
    cell.indexPath=indexPath;
    cell.dataArray=model.son;
    cell.delegate=self;
    cell.backgroundColor=[UIColor clearColor];
    return cell;
    
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    LdataModel *model=self.dataArr[indexPath.section];
    NSInteger count=0;
    for (LsonModel *MODEL in model.son) {
        count=count+MODEL.sun.count;
    }
    return 40*(model.son.count+count);
}

#pragma mark-----celldelegate
-(void)LsecondTableViewCellSelect:(UIButton *)sender withId:(NSString *)idstr withname:(NSString *)name
{
    
    [self LtreePullViewControl:sender withID:idstr withname:name];
    
}
-(void)BtnClick:(UIButton *)sender{
    
    sender.selected=!sender.selected;
    
    LdataModel *model=self.dataArr[sender.tag-10000];
    
    [self LtreePullViewControl:sender withID:model.ID withname:model.name];
    
}

-(void)LtreePullViewControl:(UIButton *)button withID:(NSString *)idStr withname:(NSString *)name{
    
    if (button.selected==YES) {
        
        [self.lwc_selectArr addObject:idStr];
        [self.lwc_selectnameArr addObject:name];
    }else{
        
        [self.lwc_selectArr removeObject:idStr];
         [self.lwc_selectnameArr removeObject:name];
    }
    
    NSLog(@"str-------------%@",[self.lwc_selectArr componentsJoinedByString:@","]);
    
    
    self.myblock([self.lwc_selectArr componentsJoinedByString:@","],[self.lwc_selectnameArr componentsJoinedByString:@","]);
    
}

@end
