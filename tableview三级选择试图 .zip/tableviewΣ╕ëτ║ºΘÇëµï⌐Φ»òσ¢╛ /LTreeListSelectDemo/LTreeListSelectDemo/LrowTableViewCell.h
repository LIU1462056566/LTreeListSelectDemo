//
//  LrowTableViewCell.h
//  eDAIFUProject
//
//  Created by 刘文超 on 2017/10/23.
//  Copyright © 2017年 刘文超. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LsunModel.h"


@protocol LrowTableViewCellDelegate <NSObject>

@optional

-(void)LrowTableViewCellSelect:(UIButton *)button withID:(NSString *)idstr withname:(NSString *)name;

@end


@interface LrowTableViewCell : UITableViewCell


@property(nonatomic,strong)LsunModel *model;
@property(nonatomic,weak)id<LrowTableViewCellDelegate>delegate;
@end
