//
//  LrowTableViewCell.m
//  eDAIFUProject
//
//  Created by 刘文超 on 2017/10/23.
//  Copyright © 2017年 刘文超. All rights reserved.
//

#import "LrowTableViewCell.h"
#import "Masonry.h"
#define LMORENCOLOR RGB(100, 147, 211, 1)
#ifndef RGB
#define RGB(R,G,B,A) [UIColor colorWithRed:R/255.0f green:G/255.0f blue:B/255.0f alpha:A]
#endif
@interface LrowTableViewCell ()
@property(nonatomic,strong)UILabel *lwc_leftLabel;
@end

@implementation LrowTableViewCell
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self=[super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self setUI];
    }return self;
}
-(void)setModel:(LsunModel *)model
{
    _model=model;
    
    self.lwc_leftLabel.text=model.name;
    
    
    
}
-(void)setUI{
    
    UILabel *leftLabel=[[UILabel alloc]init];
    [self addSubview:leftLabel];
    leftLabel.font=[UIFont systemFontOfSize:14 weight:3];
    leftLabel.text=@"刘文超2";
    leftLabel.textColor=LMORENCOLOR;
    self.lwc_leftLabel=leftLabel;
    [leftLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.offset(60);
        make.centerY.offset(0);
        make.height.offset(30);
    }];
    
    
    UIButton *button=[[UIButton alloc]init];
    [self  addSubview:button];
    [button setImage:[UIImage imageNamed:@"boxyCheckNot"] forState:UIControlStateNormal];
     [button setImage:[UIImage imageNamed:@"boxyCheckSelect"] forState:UIControlStateSelected];
      [button addTarget:self action:@selector(BtnClick:) forControlEvents:UIControlEventTouchUpInside];
    
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.offset(-10);
        make.centerY.offset(0);
        make.height.width.offset(30);
    }];
    
    
}

-(void)BtnClick:(UIButton *)sender{
    
    sender.selected=!sender.selected;
    
    if (self.delegate&&[self.delegate respondsToSelector:@selector(LrowTableViewCellSelect:withID:withname:)]) {
        [self.delegate LrowTableViewCellSelect:sender withID:self.model.ID withname:self.model.name];
    }
    
    
    
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
