//
//  LsunModel.h
//  eDAIFUProject
//
//  Created by 刘文超 on 2017/10/14.
//  Copyright © 2017年 刘文超. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LsunModel : NSObject
//**  **/
@property(nonatomic,copy)NSString *ID;
//**  **/
@property(nonatomic,copy)NSString *name;
//**  **/
@property(nonatomic,copy)NSString *parent_id;
//**  **/
@property(nonatomic,copy)NSString *type;
@end
