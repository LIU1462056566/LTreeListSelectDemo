//
//  LThreePopview.h
//  eDAIFUProject
//
//  Created by 刘文超 on 2017/11/4.
//  Copyright © 2017年 刘文超. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LThreePopview : UIView

@property(nonatomic,strong)UITableView *lwc_tableview;

@property(nonatomic,copy)NSArray *dataArr;


@property(nonatomic,copy)void(^myblock)(NSString *Idstr,NSString *str);
@end
