//
//  LsonModel.m
//  eDAIFUProject
//
//  Created by 刘文超 on 2017/10/14.
//  Copyright © 2017年 刘文超. All rights reserved.
//

#import "LsonModel.h"

@implementation LsonModel
+(NSDictionary *)mj_replacedKeyFromPropertyName
{
    // 实现这个方法的目的：告诉MJExtension框架模型中的属性名对应着字典的哪个key
    return @{
             @"ID" : @"id",
             };
}
// 这个方法对比上面的2个方法更加没有侵入性和污染，因为不需要导入Status和Ad的头文件
+ (NSDictionary *)mj_objectClassInArray{
    return @{
             @"sun":@"LsunModel",
             
             };
}
@end
