//
//  LsecondTableViewCell.h
//  LTreeListSelectDemo
//
//  Created by 刘文超 on 2017/10/23.
//  Copyright © 2017年 刘文超. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LsonModel.h"
#import "LsunModel.h"


@protocol LsecondTableViewCellDelegate <NSObject>

@optional
-(void)LsecondTableViewCellSelect:(UIButton *)sender withId:(NSString *)idstr withname:(NSString *)name;

@end


@interface LsecondTableViewCell : UITableViewCell

@property(nonatomic,strong)NSIndexPath *indexPath;

@property(nonatomic,copy)NSArray *dataArray;

@property(nonatomic,weak)id<LsecondTableViewCellDelegate>delegate;

@end
