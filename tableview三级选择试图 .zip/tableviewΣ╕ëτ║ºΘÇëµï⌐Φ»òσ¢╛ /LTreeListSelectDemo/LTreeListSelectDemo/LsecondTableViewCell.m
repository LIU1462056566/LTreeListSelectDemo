//
//  LsecondTableViewCell.m
//  LTreeListSelectDemo
//
//  Created by 刘文超 on 2017/10/23.
//  Copyright © 2017年 刘文超. All rights reserved.
//

#import "LsecondTableViewCell.h"
#import "LrowTableViewCell.h"
#import "Masonry.h"
#define LMORENCOLOR RGB(100, 147, 211, 1)
#ifndef RGB
#define RGB(R,G,B,A) [UIColor colorWithRed:R/255.0f green:G/255.0f blue:B/255.0f alpha:A]
#endif
@interface LsecondTableViewCell ()<UITableViewDelegate,UITableViewDataSource,LrowTableViewCellDelegate>
{
    BOOL isSelect[100];
    
    
}
@property(nonatomic,strong)UITableViewCell *rowTableview;
@property(nonatomic,strong)UITableView *lwc_myTableView;
@end

@implementation LsecondTableViewCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self=[super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self setUI];
    }return self;
}
-(void)setUI{
    
    
    UITableView *myTableView=[[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStyleGrouped];
    [self addSubview:myTableView];
    myTableView.delegate=self;
    myTableView.dataSource=self;
    myTableView.bounces=NO;
    self.lwc_myTableView=myTableView;
    myTableView.userInteractionEnabled=YES;
    myTableView.scrollEnabled=NO;
    
}
-(void)layoutIfNeeded
{
    [super layoutIfNeeded];
    
    
    self.lwc_myTableView.frame=CGRectMake(100, 0, self.frame.size.width,  self.frame.size.height);
    
    
    [self.lwc_myTableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.offset(0);
        make.left.offset(60);
        make.bottom.top.offset(0);
    }];
    
    //加上这句 让选择按钮不消失
    [self.lwc_myTableView reloadData];

    
    
}
-(void)setDataArray:(NSArray *)dataArray
{
    _dataArray=dataArray;
    
    
    [self.lwc_myTableView reloadData];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    LsonModel *model=self.dataArray[section];
    return model.sun.count;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.dataArray.count;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 40;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 40;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return .1;
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    
     LsonModel *model=self.dataArray[section];
    UIView *cell=[[UIView alloc]init];
    cell.backgroundColor=[UIColor whiteColor];
    UILabel *leftLabel=[[UILabel alloc]init];
    [cell addSubview:leftLabel];
    leftLabel.font=[UIFont systemFontOfSize:14 weight:3];
    leftLabel.text=model.name;
    leftLabel.textColor=LMORENCOLOR;
    
    [leftLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.offset(10);
        make.centerY.offset(0);
        make.height.offset(30);
    }];
 
    UIButton *button=[[UIButton alloc]init];
    [cell addSubview:button];
     [button setImage:[UIImage imageNamed:@"boxyCheckNot"] forState:UIControlStateNormal];
     [button setImage:[UIImage imageNamed:@"boxyCheckSelect"] forState:UIControlStateSelected];
    [button addTarget:self action:@selector(BtnClick:) forControlEvents:UIControlEventTouchUpInside];
    button.tag=1000+section;
     button.selected=isSelect[section];
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.offset(-10);
        make.centerY.offset(0);
        make.height.width.offset(30);
    }];
    
    
    UIView *lineView=[[UIView alloc]init];
    [cell addSubview:lineView];
    lineView.backgroundColor=[UIColor groupTableViewBackgroundColor];
    [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.offset(-5);
        make.height.offset(1);
        make.left.equalTo(leftLabel.mas_left).offset(0);
        make.right.offset(0);
    }];
    cell.backgroundColor=[UIColor clearColor];
    return cell;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
   
    NSString *cellID=[NSString stringWithFormat:@"cell%ld %ld",self.indexPath.section,indexPath.row];
    LrowTableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell==nil) {
        cell=[[LrowTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
       
    }
    LsonModel *model=self.dataArray[indexPath.section];
    LsunModel *model1=model.sun[indexPath.row];
    cell.model=model1;
    cell.delegate=self;
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    cell.backgroundColor=[UIColor clearColor];
    return cell;
    
}
#pragma mark----cell代理方法
-(void)LrowTableViewCellSelect:(UIButton *)button withID:(NSString *)idstr withname:(NSString *)name
{
    if (self.delegate&&[self.delegate respondsToSelector:@selector(LsecondTableViewCellSelect:withId:withname:)]) {
        [self.delegate LsecondTableViewCellSelect:button withId:idstr withname:name];
    }
   
}

-(void)BtnClick:(UIButton *)sender{
    
    sender.selected=!sender.selected;
   
    LsonModel *model=self.dataArray[sender.tag-1000];
    isSelect[sender.tag-1000]=!isSelect[sender.tag-1000];
    
    
    if (self.delegate&&[self.delegate respondsToSelector:@selector(LsecondTableViewCellSelect:withId:withname:)]) {
        [self.delegate LsecondTableViewCellSelect:sender withId:model.ID withname:model.name];
    }
    
    NSIndexSet *set = [NSIndexSet indexSetWithIndex:sender.tag-1000];
    [self.lwc_myTableView reloadSections:set withRowAnimation:UITableViewRowAnimationFade];
    

    
}


- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
