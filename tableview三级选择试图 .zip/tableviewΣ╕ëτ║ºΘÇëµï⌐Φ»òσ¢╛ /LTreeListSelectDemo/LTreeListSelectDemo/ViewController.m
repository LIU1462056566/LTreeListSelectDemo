//
//  ViewController.m
//  LTreeListSelectDemo
//
//  Created by 刘文超 on 2017/10/18.
//  Copyright © 2017年 刘文超. All rights reserved.
//

#import "ViewController.h"

#import "LThreePopview.h"
#import "LdataModel.h"
#import "MJExtension.h"
#import "AFNetworking.h"
#define SCREENWIDTH   [UIScreen mainScreen].bounds.size.width
#define SCREENHEIGHT  [UIScreen mainScreen].bounds.size.height
@interface ViewController ()
{
//    LTreeListViewController *VC;
//    TreeSelectTableViewController *VC;
//    NSMutableArray *selectedCateArray1;
//    NSMutableArray *selectedCateArray2;
//    NSArray *dataSource;
}
@property(nonatomic,strong)UIView *lwc_view;
@property(nonatomic,strong)LThreePopview *lwc_threeSelectView;
@property(nonatomic,copy)NSArray *array;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor=[UIColor redColor];
    
    
    UIButton *button=[[UIButton alloc]initWithFrame:CGRectMake(100, 200, 60, 40)];
    [self.view addSubview:button];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    button.titleLabel.font=[UIFont systemFontOfSize:14 weight:3];
    [button setTitle:@"唐醫生" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(BtnClick:) forControlEvents:UIControlEventTouchUpInside];
    button.backgroundColor=[UIColor blueColor];
    
    
    
}


-(void)BtnClick:(UIButton *)button{
    
    [self removePopSupView];
    if (self.lwc_threeSelectView==nil) {
        LThreePopview *popView=[[LThreePopview alloc]initWithFrame:CGRectMake(20, 80, SCREENWIDTH-40, SCREENHEIGHT-160)];
        [self.view addSubview:popView];
        
        self.lwc_threeSelectView=popView;
       
    }
 
//    __weak typeof(self)weaSelf=self;
    self.lwc_threeSelectView.myblock=^(NSString *str,NSString *nameStr){
//        weaSelf.lwc_diqu=str;
//        
//        weaSelf.lwc_diquLabel.text=nameStr;
    };
    
    self.lwc_threeSelectView.dataArr=self.array;
}



-(NSArray *)array
{
    if (!_array) {
        _array=[[NSArray alloc]init];
        
        
        
        
        NSArray *array=@[
                         @{@"id":@"1",
                           @"name":@"蓝天",
                           @"parent_id":@"0",
                           @"son":@[
                                   @{@"id":@"1",
                                     @"name":@"蓝天",
                                     @"parent_id":@"0",
                                     @"sun":@[
                                             @{@"id":@"1",
                                               @"name":@"蓝天",
                                               @"parent_id":@"0",
                                               @"type":@"2"},
                                             @{@"id":@"1",
                                               @"name":@"蓝天",
                                               @"parent_id":@"0",
                                               @"type":@"2"}]
                                     },
                                   @{@"id":@"1",
                                     @"name":@"蓝天",
                                     @"parent_id":@"0",
                                     @"sun":@[
                                             @{@"id":@"1",
                                               @"name":@"蓝天",
                                               @"parent_id":@"0",
                                               @"type":@"2"},
                                             @{@"id":@"1",
                                               @"name":@"蓝天",
                                               @"parent_id":@"0",
                                               @"type":@"2"}]
                                     },
                                   @{@"id":@"1",
                                     @"name":@"蓝天",
                                     @"parent_id":@"0",
                                     @"sun":@[
                                             @{@"id":@"1",
                                               @"name":@"蓝天",
                                               @"parent_id":@"0",
                                               @"type":@"2"},
                                             @{@"id":@"1",
                                               @"name":@"蓝天",
                                               @"parent_id":@"0",
                                               @"type":@"2"}]
                                     }],@"type":@"2"},
                         @{@"id":@"1",
                           @"name":@"蓝天",
                           @"parent_id":@"0",
                           @"son":@[
                                   @{@"id":@"1",
                                     @"name":@"蓝天",
                                     @"parent_id":@"0",
                                     @"sun":@[
                                             @{@"id":@"1",
                                               @"name":@"蓝天",
                                               @"parent_id":@"0",
                                               @"type":@"2"},
                                             @{@"id":@"1",
                                               @"name":@"蓝天",
                                               @"parent_id":@"0",
                                               @"type":@"2"}]
                                     },
                                   @{@"id":@"1",
                                     @"name":@"蓝天",
                                     @"parent_id":@"0",
                                     @"sun":@[
                                             @{@"id":@"1",
                                               @"name":@"蓝天",
                                               @"parent_id":@"0",
                                               @"type":@"2"},
                                             @{@"id":@"1",
                                               @"name":@"蓝天",
                                               @"parent_id":@"0",
                                               @"type":@"2"}]
                                     },
                                   @{@"id":@"1",
                                     @"name":@"蓝天",
                                     @"parent_id":@"0",
                                     @"sun":@[
                                             @{@"id":@"1",
                                               @"name":@"蓝天",
                                               @"parent_id":@"0",
                                               @"type":@"2"},
                                             @{@"id":@"1",
                                               @"name":@"蓝天",
                                               @"parent_id":@"0",
                                               @"type":@"2"}]
                                     }],@"type":@"2"},
                         @{@"id":@"1",
                           @"name":@"蓝天",
                           @"parent_id":@"0",
                           @"son":@[
                                   @{@"id":@"1",
                                     @"name":@"蓝天",
                                     @"parent_id":@"0",
                                     @"sun":@[
                                             @{@"id":@"1",
                                               @"name":@"蓝天",
                                               @"parent_id":@"0",
                                               @"type":@"2"},
                                             @{@"id":@"1",
                                               @"name":@"蓝天",
                                               @"parent_id":@"0",
                                               @"type":@"2"}]
                                     },
                                   @{@"id":@"1",
                                     @"name":@"蓝天",
                                     @"parent_id":@"0",
                                     @"sun":@[
                                             @{@"id":@"1",
                                               @"name":@"蓝天",
                                               @"parent_id":@"0",
                                               @"type":@"2"},
                                             @{@"id":@"1",
                                               @"name":@"蓝天",
                                               @"parent_id":@"0",
                                               @"type":@"2"}]
                                     },
                                   @{@"id":@"1",
                                     @"name":@"蓝天",
                                     @"parent_id":@"0",
                                     @"sun":@[
                                             @{@"id":@"1",
                                               @"name":@"蓝天",
                                               @"parent_id":@"0",
                                               @"type":@"2"},
                                             @{@"id":@"1",
                                               @"name":@"蓝天",
                                               @"parent_id":@"0",
                                               @"type":@"2"}]
                                     }],@"type":@"2"}];

        
        _array=[LdataModel mj_objectArrayWithKeyValuesArray:array];
                        [LdataModel mj_objectClassInArray];
        
        
    }return _array;
}

-(void)removePopSupView{
    __weak typeof(self)weaSelf=self;
  
    
    [weaSelf.lwc_threeSelectView removeFromSuperview];
    weaSelf.lwc_threeSelectView=nil;
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
